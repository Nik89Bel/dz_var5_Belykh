﻿namespace difzachOApract
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.List = new System.Windows.Forms.ListBox();
            this.AddText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AddBut = new System.Windows.Forms.Button();
            this.RemoveBut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // List
            // 
            this.List.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.List.FormattingEnabled = true;
            this.List.ItemHeight = 29;
            this.List.Location = new System.Drawing.Point(12, 12);
            this.List.Name = "List";
            this.List.Size = new System.Drawing.Size(342, 410);
            this.List.TabIndex = 0;
            // 
            // AddText
            // 
            this.AddText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AddText.Location = new System.Drawing.Point(475, 147);
            this.AddText.Name = "AddText";
            this.AddText.Size = new System.Drawing.Size(313, 34);
            this.AddText.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(475, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 58);
            this.label1.TabIndex = 2;
            this.label1.Text = "Введите название товара\r\nдля добавления";
            // 
            // AddBut
            // 
            this.AddBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AddBut.Location = new System.Drawing.Point(475, 316);
            this.AddBut.Name = "AddBut";
            this.AddBut.Size = new System.Drawing.Size(313, 50);
            this.AddBut.TabIndex = 3;
            this.AddBut.Text = "Добавить";
            this.AddBut.UseVisualStyleBackColor = true;
            this.AddBut.Click += new System.EventHandler(this.ДобавлениеЭлементов);
            // 
            // RemoveBut
            // 
            this.RemoveBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RemoveBut.Location = new System.Drawing.Point(475, 372);
            this.RemoveBut.Name = "RemoveBut";
            this.RemoveBut.Size = new System.Drawing.Size(313, 50);
            this.RemoveBut.TabIndex = 4;
            this.RemoveBut.Text = "Удалить";
            this.RemoveBut.UseVisualStyleBackColor = true;
            this.RemoveBut.Click += new System.EventHandler(this.УдалениеЭлементов);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.RemoveBut);
            this.Controls.Add(this.AddBut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AddText);
            this.Controls.Add(this.List);
            this.Name = "Form1";
            this.Text = "Список покупок";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox List;
        private System.Windows.Forms.TextBox AddText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AddBut;
        private System.Windows.Forms.Button RemoveBut;
    }
}

