﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace difzachOApract
{
    public partial class Form1 : Form
    {
        private List<string> products = new List<string> { "кресло", "стул", "лампа", "торшер", "диван", "торшер1" };
        public Form1()
        {
            InitializeComponent();
            ПерезаписьЛиста();
        }
        private void ПерезаписьЛиста()
        {
            List.Items.Clear();
            foreach (var product in products)
            {
                List.Items.Add(product);
            }
        }
        private void УдалениеЭлементов(object sender, EventArgs e)
        {
            if (List.SelectedIndex != -1 && List.Items.Count != 0)
            {
                string productToRemove = List.SelectedItem.ToString().ToLower();
                if (!string.IsNullOrWhiteSpace(productToRemove))
                {
                    products = products.Where(p => !p.Equals(productToRemove, StringComparison.OrdinalIgnoreCase)).ToList();
                    ПерезаписьЛиста();
                }
            }
            else
                MessageBox.Show("Для удаления выберите элемент", "Ошибка");
        }
        private void ДобавлениеЭлементов(object sender, EventArgs e)
        {
            string newProduct = AddText.Text.Trim();
            if (!string.IsNullOrWhiteSpace(newProduct))
            {
                ДобавлениеВЛист(newProduct);
                ПерезаписьЛиста();
            }
        }
        private void ДобавлениеВЛист(string product)
        {
            products.Add(product);
        }
    }
}
